package br.ufla.dcc.macarraocamaraocaramujo.dao.lista;

import br.ufla.dcc.macarraocamaraocaramujo.dao.UsuarioDAO;
import br.ufla.dcc.macarraocamaraocaramujo.modelo.Bancada;
import br.ufla.dcc.macarraocamaraocaramujo.modelo.Delivery;
import br.ufla.dcc.macarraocamaraocaramujo.modelo.TipodePedido;
import br.ufla.dcc.macarraocamaraocaramujo.modelo.Usuario;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementação do Data Access Object (Padrão de Projeto) do Usuário através de
 * Lista em memória
 * 
 * @author Paulo Jr. e Julio Alves
 */
public class UsuarioDAOLista implements UsuarioDAO {

    // instância única da classe (Padrão de Projeto Singleton)
    private static UsuarioDAOLista instancia;
    
    // lista em em memória dos usuários cadastrados
    private final List<Usuario> listaUsuario;
    private final List<TipodePedido> listaPedido;

    /**
     * Constrói o objeto já definindo 5 usuários padrões
     */
    private UsuarioDAOLista() {
        listaUsuario = new ArrayList<Usuario>();
        listaPedido = new ArrayList<TipodePedido>();
        // Cadastrei alguns usuários para testar o programa.
        char[] senha = new char[]{'1', '2', '3'};
        listaUsuario.add(new Usuario("paulo", senha, "Paulo"));
        listaUsuario.add(new Usuario("jose", senha, "José"));
        listaUsuario.add(new Usuario("flavia", senha, "Flávia"));
        listaUsuario.add(new Usuario("matheus", senha, "Matheus"));
        listaUsuario.add(new Usuario("alexandre", senha, "Alexandre"));
        
        listaPedido.add(new Delivery("Avenida Bueno da Fonseca, 268 - Lavras", 100, "20","Mussarela", 400, "6262535"));
        listaPedido.add(new Delivery("Rua da Ufla, 88 - Lavras", 20, "10","Mussarela", 200, "272625252"));
        listaPedido.add(new Bancada(50, 100, "20","Mussarela", 400, "373737223"));
    
    
    }

    /**
     * Retorna a instância única da classe (Padrão de Projeto Singleton)
     * 
     * @return A instância única da classe
     */
    public static UsuarioDAOLista obterInstancia() {
        if (instancia == null) {
            instancia = new UsuarioDAOLista();
        }
        return instancia;
    }

    /**
     * Retorna o usuário a partir de seu login
     * 
     * @param login Login do usuário a ser retornado.
     * @return Usuário correspondente ao login passado.
     */
    @Override
    public Usuario obterUsuarioPeloLogin(String login) {
        for (Usuario u : listaUsuario) {
            if (login.equals(u.obterLogin())) {
                return u;
            }
        }
        return null;
    }
    
    @Override
    public TipodePedido obterPedidopeloLogin(String login) {
        for (TipodePedido u : listaPedido) {
            if (login.equals(u.getNpedido())) {
                return u;
            }
        }
        return null;
    }

    /**
     * Cadastra o usuário passado.
     * 
     * @param usuario Usuário a ser cadastrado.
     */
    @Override
    public void adicionarUsuario(Usuario usuario) {
        listaUsuario.add(usuario);
    }
    @Override
    public void adicionarPedido(TipodePedido pedido) {
        listaPedido.add(pedido);
    }
    
    
}