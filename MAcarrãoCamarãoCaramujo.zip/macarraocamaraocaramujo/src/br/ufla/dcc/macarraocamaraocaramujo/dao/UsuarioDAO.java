package br.ufla.dcc.macarraocamaraocaramujo.dao;

import br.ufla.dcc.macarraocamaraocaramujo.modelo.TipodePedido;
import br.ufla.dcc.macarraocamaraocaramujo.modelo.Usuario;

/**
 * Interface do Data Access Object (Padrão de Projeto) do Usuário
 * 
 * @author Paulo Jr. e Julio Alves
 */
public interface UsuarioDAO {
    /**
     * Retorna o usuário a partir de seu login
     * 
     * @param login Login do usuário a ser retornado.
     * @return Usuário correspondente ao login passado.
     */
    public Usuario obterUsuarioPeloLogin(String login);
    public TipodePedido obterPedidopeloLogin (String login);
    
    /**
     * Cadastra o usuário passado.
     * 
     * @param usuario Usuário a ser cadastrado.
     */
    public void adicionarUsuario(Usuario usuario);
    public void adicionarPedido(TipodePedido pedido);
    
}