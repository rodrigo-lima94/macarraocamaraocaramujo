
package br.ufla.dcc.macarraocamaraocaramujo.modelo;

 /**
 Esta Classe é responsável pela implementação da Classe Delivery no sistema, que é uma subClasse do TipodePedido,
 * Essa subclasse abrange os pedidos que tem como caracteristica serem feitas como delivery pelo comercio. 
 * Software MacarrãoCamarãCaramujo, implementado como trabalho final da disciplina de POO 2016-02.
 * Versão 1.0
 * Autores Grupo MacarrãoCamarãoCaramujo
 */
public class Delivery extends TipodePedido{
    private String endereco;
    /*
    Construtor da Classe
    */
    public Delivery (String endereco, int npedido, String pizzaqtde, String sabor, double precototal, String cartao){
        super(npedido, pizzaqtde, sabor, precototal, cartao);
        this.endereco =  endereco;
    }
    /*
    Metodos get e set para os atributos da Classe
    */
    public String getEndereco(){
        return endereco;
    }
    public void setEndereco (String endereco){
        this.endereco = endereco;
    }
    
    /* 
    Implementação do metodo getInfo que retorna as informações do pedido realizado
    */
    @Override
    public String getInfo(){
        return String.format("\n\nPedido Delivery: \n Pedido numero:"  + 
                super.getNpedido() +  "\n numero de pizzas:" +
                super.getPizzaqtde()+ "\n Sabor:" +
                super.getSabor()+"\n Preço pago:" +
                super.getPrecototal() + ", \n numero cartão=" + 
                super.getCartao() + "\n Endereço: "+ endereco);
        
      
        
    }
}
