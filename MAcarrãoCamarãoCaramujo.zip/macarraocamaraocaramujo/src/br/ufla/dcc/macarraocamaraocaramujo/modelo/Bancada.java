
package br.ufla.dcc.macarraocamaraocaramujo.modelo;
 /**
 Esta Classe é responsável pela implementação da Classe Bancada no sistema, que é uma subClasse do TipodePedido,
 * Essa subclasse abrange os pedidos que tem como caracteristica serem feitas no balcão do comercio. 
 * Software MacarrãoCamarãCaramujo, implementado como trabalho final da disciplina de POO 2016-02.
 Versão 1.0
 * Autores Grupo MacarrãoCamarãoCaramujo
 */
public class Bancada extends TipodePedido{
   
private int mesa;
/*Construtor

*/
    public Bancada (int mesa, int npedido, String pizzaqtde, String sabor,double precototal, String cartao){
        super(npedido, pizzaqtde, sabor, precototal, cartao);
        this.mesa = mesa;
    }
    /*
    Metodos get e set para os atributos da classe
    */
    public int getMesa(){
        return mesa;
    }
    
    
    public void setMesa (String endereco){
        this.mesa = mesa;
    }
   /*
    Criação do Metodo getInfo que retorna as informações recebidas em cada atributo da classe
    */ 
    @Override
    public String getInfo(){
        return String.format("\n\n Pedido realizado na bancada: \n Pedido numero:"  + 
               
                super.getNpedido() +  "\n numero de pizzas:" +
                super.getPizzaqtde()+ "\n Sabor:" +
                super.getSabor()+"\n Preço pago:" +
                super.getPrecototal() + ", \n numero cartão:" + 
                super.getCartao() + "\n Número da mesa: "+ mesa );
      
        
    }
}
