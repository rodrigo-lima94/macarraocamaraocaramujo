
package br.ufla.dcc.macarraocamaraocaramujo.modelo;

 /**
 Esta Classe é responsável pela implementação da Classe TipodePedido no sistema, que é uma Classe Mão das classes PedidedeBancada e PeddoDelivery,
 * Essa classe abrange todos os pedidos  feitos no comercio. 
 * Software MacarrãoCamarãCaramujo, implementado como trabalho final da disciplina de POO 2016-02.
 * Versão 1.0
 * Autores Grupo MacarrãoCamarãoCaramujo
 */
    public abstract class TipodePedido {
        /*
        parametros da Classe
        */
    private  int npedido;
    private String pizzaqtde;
    private double precototal;
    private String cartao;
    private String sabor;
/*
    Construtor da Classe
    */
    public TipodePedido(int npedido, String pizzaqtde,String sabor, double precototal, String cartao) {
        this.npedido = npedido;
        this.pizzaqtde = pizzaqtde;
        this.precototal = precototal;
        this.cartao = cartao;
        this.sabor = sabor;
   
    }
    /*
    Metodos Get e Sets dos Atributos da Classe
    */
    
    public void setPreco(double precototal){
    this.precototal = precototal;
}
    
    public void setCartao(String cartao){
    this.cartao = cartao;
}
public void setQtde(String pizzaqtde){
    this.pizzaqtde = pizzaqtde;
}
     public int getNpedido() {
        return npedido;
    }
     public double getPrecototal() {
        return precototal;
    }
     public  String getPizzaqtde(){
         return pizzaqtde;
     }
     
public void setNPedido(int npedido){
    this.npedido = npedido;
}     
public String getCartao(){
         return cartao;
     }
public String getSabor(){
         return sabor;
     }
@Override
    public String toString() {
        return String.valueOf(npedido);
    }


/* 
    Criação do metodo getInf que retorna as informações do pedido realizado
    */
public abstract String getInfo();    
public void setSabor(String sabor){
    this.sabor = sabor;
}
 @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TipodePedido other = (TipodePedido) obj;
        if (this.npedido != other.npedido) {
            return false;
        }
        return true;
    }


}
