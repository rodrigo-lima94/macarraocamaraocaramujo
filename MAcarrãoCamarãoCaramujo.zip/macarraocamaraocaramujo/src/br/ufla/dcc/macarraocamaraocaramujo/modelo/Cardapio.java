package br.ufla.dcc.macarraocamaraocaramujo.modelo;

import br.ufla.dcc.macarraocamaraocaramujo.modelo.Usuario;
import br.ufla.dcc.macarraocamaraocaramujo.servicos.GerenciadorUsuarios;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 Esta Classe é responsável pela interface que mostra o cardápio no sistema
 * do software MacarrãoCamarãCaramujo, implementado como trabalho final da disciplina de POO 2016-02.
 * Versão 1.0
 * Autores Grupo MacarrãoCamarãoCaramujo
 */


public class Cardapio extends JFrame {
    private GridBagLayout gbl1;
    private GridBagConstraints gbc1;
   
    
    public Cardapio() {
        
        gbl1 = new GridBagLayout();
        gbc1 = new GridBagConstraints();
        setLayout(new GridLayout(7, 1, 1, 1));
        setSize(400, 612);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        construirTela();
            }
    
    public void construirTela() {
        
       
        JLabel lbCardapio = new JLabel("Cardápio Pizzas:");
        adicionarComponente(lbCardapio, GridBagConstraints.BOTH, 0, 0, 1, 1);
        JLabel imgExib = new JLabel(new ImageIcon(getClass().getResource("/img/exibe.png")));
        adicionarComponente(imgExib,GridBagConstraints.BOTH , 0, 0, 1, 2);
         
        JLabel lbMus = new JLabel("Mussarela   R$20,00");
        adicionarComponente(lbMus, GridBagConstraints.BOTH, 1, 0, 1, 1);
        JLabel imgMussa = new JLabel(new ImageIcon(getClass().getResource("/img/muss.png")));
        adicionarComponente(imgMussa,GridBagConstraints.BOTH , 1, 1, 1, 2);
        
        JLabel lbCal = new JLabel("Calabresa   R$20,00");
        adicionarComponente(lbCal, GridBagConstraints.BOTH, 3, 0, 1, 1);
        JLabel imgCal = new JLabel(new ImageIcon(getClass().getResource("/img/calab.png")));
        adicionarComponente(imgCal,GridBagConstraints.BOTH , 3, 1, 1, 2);
        
        JLabel lbFran = new JLabel("Frango     R$20,00");
        adicionarComponente(lbFran, GridBagConstraints.BOTH, 5, 0, 1, 1);
        JLabel imgFran = new JLabel(new ImageIcon(getClass().getResource("/img/frango.png")));
        adicionarComponente(imgFran,GridBagConstraints.BOTH , 5, 1, 1, 2);
      
        JButton btnVoltar = new JButton("Voltar", new ImageIcon(getClass().getResource("/img/voltar.png")) );
        adicionarComponente(btnVoltar,GridBagConstraints.BOTH , 7, 2, 2, 2);
        btnVoltar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               dispose();
                
            }
        });
    }
    /*
    Metodo que adiciona componentes a tela
    */
    
    private void adicionarComponente(Component comp,
            int fill, int linha, int coluna,
            int largura, int altura) {
        gbc1.fill = fill;
        gbc1.gridx = coluna;
        gbc1.gridy = linha;
        gbc1.gridwidth = largura;
        gbc1.gridheight = altura;
        gbc1.insets = new Insets(7, 1, 1 , 1);
        gbl1.setConstraints(comp, gbc1);
        add(comp);
    }

   

    
}
