package br.ufla.dcc.macarraocamaraocaramujo.servicos;


import br.ufla.dcc.macarraocamaraocaramujo.modelo.Bancada;
import br.ufla.dcc.macarraocamaraocaramujo.modelo.Delivery;
import br.ufla.dcc.macarraocamaraocaramujo.modelo.TipodePedido;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.JOptionPane;


public class Controle {
 /**
 Esta Classe é responsável pelo controle do sistema, aqui será implementados metodos de busca, edição, exclusão e adição de pedidos ao
 * Software MacarrãoCamarãCaramujo, implementado como trabalho final da disciplina de POO 2016-02.
 * Versão 1.0
 * Autores Grupo MacarrãoCamarãoCaramujo
 */
   
private static ArrayList<TipodePedido> cadastro;


public Controle(){
       if (cadastro == null){
           cadastro = new ArrayList<>();
           
       }
}
/*Metodo para adicionar cadastro de pedidos

*/

    public static boolean adicionarCadastro(TipodePedido ca) {
        if(!cadastro.contains(ca))  {  
        cadastro.add(ca);
        return true;
        }else{
            return false;
        }
    }
    /*Metodo para excluir cadastro de pedidos ja realizados

*/
    public static void excluirCadatro(TipodePedido ca){
        cadastro.remove(ca);
    }

      public List<TipodePedido> getAllUnidade() {
        return Collections.unmodifiableList(cadastro);
    }
public static String getCadastro(){
    String texto= "";
    for (TipodePedido ca: cadastro){
        texto += ca.getInfo();
        
    }
    return texto;
}
public static int getQtdUnidade() {
        int qtd = cadastro.size();
        return qtd;
    }

/*Metodo para buscar  cadastro de pedidos atraves do numero do pedido informado

*/
public static List<TipodePedido> buscaPedidos(int codigo) {
  
        List<TipodePedido> buscaPedido = new ArrayList<TipodePedido>();
        for (int i = 0; i < cadastro.size(); i++) {
            if (cadastro.get(i).getNpedido() == codigo) {
                buscaPedido.add(cadastro.get(i));
                }
          
        }
        return Collections.unmodifiableList(buscaPedido);
    }

public List<TipodePedido> getListaDelivery() {

        List<TipodePedido> PedidoDelivery = new ArrayList<>();
        for (TipodePedido tp : cadastro) {
            if (tp instanceof Delivery) {
                PedidoDelivery.add(tp);
            }
        }
        return Collections.unmodifiableList(PedidoDelivery);
    }
public List<TipodePedido> getListaBancada() {

        List<TipodePedido> PedidoBancada = new ArrayList<>();
        for (TipodePedido tp : cadastro) {
            if (tp instanceof Bancada) {
                PedidoBancada.add(tp);
            }
        }
        return Collections.unmodifiableList(PedidoBancada);
    }
}