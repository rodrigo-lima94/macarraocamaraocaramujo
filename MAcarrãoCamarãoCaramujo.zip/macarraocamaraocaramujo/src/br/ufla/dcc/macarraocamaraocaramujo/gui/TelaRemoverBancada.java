
package br.ufla.dcc.macarraocamaraocaramujo.gui;
import br.ufla.dcc.macarraocamaraocaramujo.modelo.Bancada;
import br.ufla.dcc.macarraocamaraocaramujo.servicos.Controle;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 * /**
 Esta Classe é responsável pela interface Grafica que mostra os pedidos ja cadastrados no sistema do tipo bancada
 * do software MacarrãoCamarãCaramujo, implementado como trabalho final da disciplina de POO 2016-02.
 * Versão 1.0
 * Autores Grupo MacarrãoCamarãoCaramujo
 */

public final class TelaRemoverBancada extends JFrame{

    private GridBagLayout gbl;
    private GridBagConstraints gbc;
    private JLabel lbPedidos;
    private JComboBox cbPedidos;
    private JButton btnApagar;
    private Controle lista;
    private Bancada bancadaSel;
    private JTextArea txtConteudo;
  

public TelaRemoverBancada(){
        
        gbl = new GridBagLayout();
        gbc = new GridBagConstraints();
        setSize(1024, 620);
        setLayout(gbl);        setSize(1024, 620);

        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        lista = new Controle();
         construirTela();
}
/**
 * Adiciona componentes como botões, caixa de Textos e textos na tela com suas
 * respectivas funções associadas
 */
    public void construirTela() {
        lbPedidos = new JLabel("Selecione o código do pedido realizado na bancada");
        adicionarComponente(lbPedidos, GridBagConstraints.NONE, 0, 3, 2, 1);
        
        cbPedidos = new JComboBox(lista.getListaBancada().toArray());
        cbPedidos.setSelectedIndex(-1);
        cbPedidos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JComboBox jb = (JComboBox) e.getSource();
                bancadaSel = (Bancada) jb.getSelectedItem();
                exibirPedido(bancadaSel);
            }
        });
        
      
        adicionarComponente(cbPedidos,
                GridBagConstraints.HORIZONTAL,
                1, 3, 2, 1);
        
         txtConteudo = new JTextArea(20, 20);
      adicionarComponente(txtConteudo, GridBagConstraints.BOTH, 3, 0, 15, 10);
      
        
        JButton btnVoltar = new JButton("Voltar para o Inicio");
         adicionarComponente(btnVoltar,GridBagConstraints.BOTH , 20, 5, 1, 1);
         
     
        btnApagar = new JButton("Apagar Pedido");
        adicionarComponente(btnApagar, GridBagConstraints.BOTH, 20, 0, 1, 1);
        
        btnApagar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
               apagarPedido(bancadaSel);
            }catch(Exception ex){
                Logger.getLogger(TelaRemoverDelivery.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        }
        );
         
        
        
         btnVoltar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                
            }
        });
    }
    /**
     * Adiciona os componentes À tela
     * @param comp
     * @param fill
     * @param linha
     * @param coluna
     * @param largura
     * @param altura 
     */
     private void adicionarComponente(Component comp,
            int fill, int linha, int coluna,
            int largura, int altura) {
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.fill = fill;
        gbc.gridx = coluna;
        gbc.gridy = linha;
        gbc.gridwidth = largura;
        gbc.gridheight = altura;
        gbc.insets = new Insets(3, 3, 3, 3);
        gbl.setConstraints(comp, gbc);
        add(comp);
    }
     
       public void  exibirPedido(Bancada pedido){ 
      txtConteudo.setEditable(false);
      txtConteudo.setText(pedido.getInfo());
     }
       /*
       Metodo para fazer a excluisão do pedido selecionado
       @thow com tratamento de possiveis erros 
       */
   
   private void apagarPedido(Bancada bancadaSel) throws Exception {
               try{ 
                   lista.excluirCadatro(bancadaSel);
                    JOptionPane.showMessageDialog(null, "Pedido da bancada excluido com Sucesso", "Excluir", JOptionPane.INFORMATION_MESSAGE);
                dispose();
               }catch (Exception e){
                 JOptionPane.showMessageDialog(null, "Não há mais nenhum pedido para ser excluido", "Excluir", JOptionPane.INFORMATION_MESSAGE);  
               } 
} 

}
  