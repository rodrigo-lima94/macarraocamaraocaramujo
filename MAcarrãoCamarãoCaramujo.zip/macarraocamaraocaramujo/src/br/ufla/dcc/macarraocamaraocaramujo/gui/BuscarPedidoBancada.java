package br.ufla.dcc.macarraocamaraocaramujo.gui;

import br.ufla.dcc.macarraocamaraocaramujo.servicos.Controle;
import br.ufla.dcc.macarraocamaraocaramujo.modelo.TipodePedido;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
/**
 Esta Classe é responsável pela interface Grafica para a função de Busca de Pedidos 
 * do software MacarrãoCamarãCaramujo, implementado como trabalho final da disciplina de POO 2016-02.
 * Versão 1.0
 * Autores Grupo MacarrãoCamarãoCaramujo
 */
public final class BuscarPedidoBancada extends JFrame {
    /* Declaração de atributos utilizados */ 
    private GridBagLayout gbl;
    private GridBagConstraints gbc;
    private JLabel lbLogo;
    private JLabel lbMessage;
    private Controle listaPedidos;
    private JLabel PedidosBancada;
    private JLabel PedidosDelivery;
    private JLabel lbCodigo;
    private JTextField txtCodigo;
    private JLabel lbNome;
    private JTextField txtNome;
    private JButton btnEditar;
    private JButton btnBuscar;
    private JButton btnVoltar;
    private JPanel pBotoes;
    private JTextArea taInfo;
    private JComboBox<TipodePedido> CbPed;
    private TipodePedido Peduni;
    private JTextArea txtConteudo;
    
    public BuscarPedidoBancada() {
        /*Set dos parametros da Janela construída
        
        */
        super ("Busca - Pedidos");
        gbl = new GridBagLayout();
        gbc = new GridBagConstraints();
        setSize(1024, 620);
        setLayout(gbl);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                confirmaFechar();
            }
        });
        
        construirTela();
        pack();
    }

    /**
     * Método para construir tela
     */
    /**
     * Construção dos Componentes da Tela, como Botões, Caixas de texto, 
     * e inserção das funções dos Botões ao serem acionados
     */
    public void construirTela() {
        lbLogo = new JLabel(new ImageIcon(getClass().getResource("/img/visualizar.png")));
        adicionarComponente(lbLogo, GridBagConstraints.CENTER,
                0, 0, 5, 3);
        lbMessage = new JLabel("Digite o Numero do Pedido");
        adicionarComponente(lbMessage, GridBagConstraints.NONE,
                3, 1, 2, 1);
        
        txtCodigo = new JTextField(5);
        adicionarComponente(txtCodigo, GridBagConstraints.HORIZONTAL,
                3, 3, 2, 1);
        
        btnBuscar = new JButton("Buscar",
                new ImageIcon(getClass().getResource("/img/iconBusca.png")));
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    buscarUnidade();
                } catch (Exception ex) {
                    Logger.getLogger(BuscarPedidoBancada.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
        adicionarComponente(btnBuscar, GridBagConstraints.HORIZONTAL,
                3, 5, 2, 1);
        
        taInfo = new JTextArea(20, 6);
        adicionarComponente(taInfo, GridBagConstraints.HORIZONTAL,
                4, 1, 6, 1);
        btnVoltar = new JButton("Voltar",
                new ImageIcon(getClass().getResource("/img/voltar.png")));
        btnVoltar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        adicionarComponente(btnVoltar, GridBagConstraints.HORIZONTAL,
                17, 5, 0, 0);
        
    }

    /**
     * Método para adição de componentes gráficos
     *
     * @param comp Component
     * @param fill int
     * @param linha int
     * @param coluna int
     * @param largura int
     * @param altura int
     */
    private void adicionarComponente(Component comp,
            int fill, int linha, int coluna,
            int largura, int altura) {
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.fill = fill;
        gbc.gridx = coluna;
        gbc.gridy = linha;
        gbc.gridwidth = largura;
        gbc.gridheight = altura;
        gbc.insets = new Insets(3, 3, 3, 3);
        gbl.setConstraints(comp, gbc);
        add(comp);
    }

    /**
     * Método para confirmação de encerramento de janela
     */
    private void confirmaFechar() {
        dispose();
    }

    /**
      Nesta Função Chamamos o Método buscar, implementado na Classe controle, nele é feita a comparação entre o 
      codigo digitado e um Arrays de Pedidos, caso seja encontrado o codigo em algum pedido ele retorna suas informações
      */
    private void buscarUnidade() {
        int codigoBusca = Integer.parseInt(txtCodigo.getText());
        String listaPed = "";
        /*Esta variável ListaPed2nfoi criada para consertar um bug que estava acontecendo no nosso programa,
        ja que a variavel listaPed não aceitava receber buscaPedidos.get(i).getInfo();
        ela então, serve para mostrar na tela todas as informações do pedido encontrado
        */
        String ListaPed2 = "";
        List<TipodePedido> buscaPedidos = null;

               buscaPedidos = Controle.buscaPedidos(codigoBusca);
        /*Aqui temos um Laço que vai de i=0 até o tamanho do vetor buscaPedidos
               
               */
                     for (int i = 0; i < buscaPedidos.size(); i++) {
                         
                        listaPed += buscaPedidos.get(i);
                        ListaPed2 += buscaPedidos.get(i).getInfo();
                                                 }
                    taInfo.setText(ListaPed2);
                     
                }
   
}