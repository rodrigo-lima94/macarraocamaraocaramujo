
package br.ufla.dcc.macarraocamaraocaramujo.gui;


import br.ufla.dcc.macarraocamaraocaramujo.servicos.Controle;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;


/**
 * /**
 Esta Classe é responsável pela interface Grafica que mostra os pedidos ja cadastrados no sistema
 * do software MacarrãoCamarãCaramujo, implementado como trabalho final da disciplina de POO 2016-02.
 * Versão 1.0
 *  Autores Grupo MacarrãoCamarãoCaramujo
 */
public final class TelaRegistro extends JFrame {
    private GridBagLayout gbl;
    private GridBagConstraints gbc;
    private JTextArea txtConteudo;
    private JLabel lbQtdePedidos;
    private Controle controle = new Controle();
       
     public TelaRegistro() {
        gbl = new GridBagLayout();
        gbc = new GridBagConstraints();
        
        setSize(1024, 768);
        setLayout(gbl);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        construirTela();
    }
      
       /**
     * Adiciona componentes à tela como botões, caixa de textos e textos com suas respectivas funções associadas
     */
        public void construirTela() {
        JLabel lbPoo = new JLabel("Pizzaria POO");
        adicionarComponente(lbPoo, GridBagConstraints.HORIZONTAL,
                0, 0, 5, 1);
 
      JLabel lbPedidos = new JLabel("Pedidos Realizados \n");
        adicionarComponente(lbPedidos, GridBagConstraints.HORIZONTAL,
                1, 0, 1, 1);
      
      lbQtdePedidos = new JLabel("0");
        adicionarComponente(lbQtdePedidos, GridBagConstraints.NONE,
                1, 1, 1, 1);
        
        lbQtdePedidos.setText(String.valueOf(Controle.getQtdUnidade()));
        
        
        txtConteudo = new JTextArea(20, 20);
                
        adicionarComponente(txtConteudo, GridBagConstraints.BOTH, 3, 0, 15, 10);
        txtConteudo.setEditable(false);
        txtConteudo.setText(Controle.getCadastro());
        
         
         
        JButton btnVoltar = new JButton("Voltar para o Inicio");
         adicionarComponente(btnVoltar,GridBagConstraints.BOTH , 20, 5, 1, 1);
         
     
          
         
         btnVoltar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                
            }
        });
                
       
    
}
  /**
     * Adiciona um componente à tela.
     */
        
 private void adicionarComponente(Component comp,
            int fill, int linha, int coluna,
            int largura, int altura) {
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.fill = fill;
        gbc.gridx = coluna;
        gbc.gridy = linha;
        gbc.gridwidth = largura;
        gbc.gridheight = altura;
        gbc.insets = new Insets(1, 1, 1, 1);
        gbl.setConstraints(comp, gbc);
        add(comp);
    }
 

      

      
}