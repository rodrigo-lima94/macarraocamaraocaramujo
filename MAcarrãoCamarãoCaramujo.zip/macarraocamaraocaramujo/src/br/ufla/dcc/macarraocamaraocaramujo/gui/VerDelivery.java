package br.ufla.dcc.macarraocamaraocaramujo.gui;



import br.ufla.dcc.macarraocamaraocaramujo.modelo.Delivery;
import br.ufla.dcc.macarraocamaraocaramujo.modelo.TipodePedido;
import br.ufla.dcc.macarraocamaraocaramujo.servicos.Controle;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 Esta Classe é responsável pela interface Grafica responsável por cadastrar os pedidos do tipo Delivery no sistema
 * do software MacarrãoCamarãCaramujo, implementado como trabalho final da disciplina de POO 2016-02.
 * Versão 1.0
 * Autores Grupo MacarrãoCamarãoCaramujo
 */
public class VerDelivery extends JFrame {
    private Controle controle  = new Controle();
    private JDialog janela;
    private GridBagLayout gbl3;
    private GridBagConstraints gbc3;
    public static double preco;
    public static String n;
    private JButton btnFinalizar;
    private JLabel lbCodigo;
    private JLabel lbNumero;
    private JLabel lbEnd;
    private JTextField txtCodigo;
    private JTextField txtSabores;
    private JTextField txtNumero;
    private JTextField txtEnd;
     public static double w;
       
    
    public VerDelivery() {
        janela = new JDialog();
        gbl3 = new GridBagLayout();
        gbc3 = new GridBagConstraints();
        
       
        setSize(1024, 768);
        setLayout(gbl3);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        construirTela();
    }
   
       /*
        Adiciona componentes a tela como botões, textos e caixa de textos com suas respectivas atribuições e chamada de métodos
        
        */
    public void construirTela() {
        
        
        JLabel lbCardapio = new JLabel("Pizzaria POO");
        adicionarComponente(lbCardapio, GridBagConstraints.BOTH, 1, 0, 0, 1);
        
         
        JLabel lbPedido = new JLabel("Realizar Pedido");
        adicionarComponente(lbPedido, GridBagConstraints.BOTH, 2, 0, 0, 1);
    
        
       
       
        
        JLabel lbQuantidade = new JLabel("Selecione a quantidade de Pizzas");
        adicionarComponente(lbQuantidade, GridBagConstraints.NONE,
                3, 0, 1, 1);
        
       
               
        
        
        JComboBox<String> cbQtde;
        cbQtde = new JComboBox<String>();
        cbQtde.addItem("0");
        cbQtde.addItem("1");
        cbQtde.addItem("2");
        cbQtde.addItem("3");
        cbQtde.addItem("4");
        cbQtde.addItem("5");
       
        adicionarComponente(cbQtde, GridBagConstraints.NONE,
                3, 4, 1, 1);
    
        
        JLabel lbSabores = new JLabel("Descreva os sabores:"); 
        adicionarComponente(lbSabores, GridBagConstraints.NONE,
                4, 0, 1, 1);

        
        txtSabores = new JTextField(16);
        adicionarComponente(txtSabores, GridBagConstraints.BOTH,
                4, 4, 1, 1);
         
        
        lbCodigo = new JLabel("Código");
        adicionarComponente(lbCodigo, GridBagConstraints.NONE,
                5, 0, 1, 1);
        txtCodigo = new JTextField(6);
        adicionarComponente(txtCodigo, GridBagConstraints.NONE,
                5, 4, 1, 1);       
       
        n = cbQtde.getSelectedItem().toString();
        
 
        
        
        lbNumero = new JLabel("Digite o número do cartão");
        adicionarComponente(lbNumero, GridBagConstraints.NONE,
                16, 0, 1, 1);
                
       txtNumero = new JTextField(16);
        adicionarComponente(txtNumero, GridBagConstraints.BOTH,
                16, 4, 1, 1);
         
        lbEnd = new JLabel("Digite o endereco");
        adicionarComponente(lbEnd, GridBagConstraints.NONE,
                20, 0, 1, 1);
                
       txtEnd = new JTextField(16);
        adicionarComponente(txtEnd, GridBagConstraints.BOTH,
                20, 4, 1, 1);
       
        
               
         
         JLabel lbPreco = new JLabel("Preço total:");
         adicionarComponente(lbPreco,GridBagConstraints.BOTH , 22, 0, 1, 1); 
        
         JLabel lbPrecoT = new JLabel();
        lbPrecoT.setText(String.valueOf(preco));
         adicionarComponente(lbPrecoT,GridBagConstraints.BOTH , 22, 2, 1, 1); 
        
         
         
         cbQtde.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
             n = cbQtde.getSelectedItem().toString();
             
           
           int i = Integer.parseInt(n);
                      
             preco = 20*i;
             w= preco;
             lbPrecoT.setText(String.valueOf(preco)); 
             

            
            
            }
        });
         
         
        
       
         
          btnFinalizar = new JButton("Finalizar");
         adicionarComponente(btnFinalizar,GridBagConstraints.BOTH , 24, 0, 1, 1); 
          
          
         JButton btnVoltar = new JButton("Voltar");
         adicionarComponente(btnVoltar,GridBagConstraints.BOTH , 24, 4, 1, 1);  
         
         btnVoltar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               dispose();
                
            }
        });
        
        btnFinalizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    
                 cadastrarPedido();
               preco = 0;
                }catch(Exception ex) {
                    Logger.getLogger(VerDelivery.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

     private void adicionarComponente(Component comp,
            int fill, int linha, int coluna,
            int largura, int altura) {
        gbc3.anchor = GridBagConstraints.LINE_START;
        gbc3.fill = fill;
        gbc3.gridx = coluna;
        gbc3.gridy = linha;
        gbc3.gridwidth = largura;
        gbc3.gridheight = altura;
        //gbc3.insets = new Insets(4, 3, 3, 3);
        gbl3.setConstraints(comp, gbc3);
        add(comp);
    }
     
     /**
      * Tratamento de exceção, para o cadastramento de pedidos, aqui trata-se
      * de erros do tipo, codigo ja cadastrado, e tipo de entrada para codigo incorreto
      * @throws Exception 
      */

 private void cadastrarPedido() throws Exception{
      int codigo = 0;
      try{ 

     codigo = Integer.parseInt(txtCodigo.getText());
     String pizzaqtde = n;
     double precototal = w;
     String sabor = txtSabores.getText();
     String endereco = txtEnd.getText();
     String cartao = txtNumero.getText();
     TipodePedido cadastro = new Delivery(endereco, codigo, pizzaqtde, sabor ,precototal,cartao);      
     if (!controle.adicionarCadastro(cadastro)){
      JOptionPane.showMessageDialog(null, "Cógido já cadastrado","Erro!", JOptionPane.ERROR_MESSAGE);
     }else{
      JOptionPane.showMessageDialog(null, "Pedido Realizado com sucesso!", "Delivery", JOptionPane.INFORMATION_MESSAGE);
                    dispose();   
     }
      }catch(Exception e){
         JOptionPane.showMessageDialog(null, "Erro no Cadastro!\nO código deve conter apenas números!", "Erro!", JOptionPane.ERROR_MESSAGE); 
      }
 
 }

}