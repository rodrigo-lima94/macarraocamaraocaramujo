package br.ufla.dcc.macarraocamaraocaramujo.gui;

import br.ufla.dcc.macarraocamaraocaramujo.modelo.Bancada;
import br.ufla.dcc.macarraocamaraocaramujo.modelo.TipodePedido;
import br.ufla.dcc.macarraocamaraocaramujo.servicos.Controle;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 Esta Classe é responsável pela interface Grafica para a função de Editar de Pedidos do tipo em Bancada 
 * do software MacarrãoCamarãCaramujo, implementado como trabalho final da disciplina de POO 2016-02.
 * Versão 1.0
 * Autores Grupo MacarrãoCamarãoCaramujo
 */
public class EditarBancada extends JFrame {
    private Controle controle  = new Controle();
    private JDialog janela;
    private GridBagLayout gbl3;
    private GridBagConstraints gbc3;
    public static double preco;
    public static String n;
    private JButton btnFinalizar;
    private JLabel lbCodigo;
    private JLabel lbNumero;
    private JLabel lbEnd;
    private JLabel lbQtde;
    private JLabel lbPrecoTotal;
    private JTextField txtQtde;
    private JTextField txtCodigo;
    private JTextField txtSabores;
    private JTextField txtNumero;
    private JTextField txtEnd;
    private JTextField txtPrecoTotal;
    public static double w;
    private JLabel lbPedidos;
    private JComboBox cbPedido;
    private Controle list;
    private Bancada bancadaSel;
   
    /*
    Set dos parametros da tela a ser construida
    */
    public EditarBancada() {
        janela = new JDialog();
        gbl3 = new GridBagLayout();
        gbc3 = new GridBagConstraints();
        
       
        setSize(1024, 768);
        setLayout(gbl3);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        list = new Controle();
        construirTela();
    }
   
   /*
    Criação dos componentes da tela como textos e botões, assim como as funções de cada botao
    */ 
    public void construirTela() {
        lbPedidos = new JLabel("Selecione o código do pedido da bancada");
         adicionarComponente(lbPedidos, GridBagConstraints.NONE,
                0, 3, 2, 1);
        
        cbPedido = new JComboBox(list.getListaBancada().toArray());
        cbPedido.setSelectedIndex(-1);
        cbPedido.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JComboBox jb = (JComboBox) e.getSource();
                bancadaSel = (Bancada) jb.getSelectedItem();
                exibirPedido(bancadaSel);
            }
        });
         adicionarComponente(cbPedido,GridBagConstraints.HORIZONTAL,
                1, 3, 2, 1);
        
        
       lbCodigo = new JLabel("Código");
        adicionarComponente(lbCodigo, GridBagConstraints.NONE,
                2, 0, 1, 1);
        
        txtCodigo = new JTextField(6);
        txtCodigo.setEditable(true);
        adicionarComponente(txtCodigo, GridBagConstraints.NONE,
                2, 4, 1, 1);   
       
        
        lbQtde = new JLabel("Quantidade de Pizzas");
        adicionarComponente(lbQtde, GridBagConstraints.NONE,
                3, 0, 1, 1);
        
       txtQtde = new JTextField(5);
       txtQtde.setEditable(true);
        adicionarComponente(txtQtde, GridBagConstraints.NONE,
                3, 4, 1, 1);
    
        
        JLabel lbSabores = new JLabel("Sabores:"); 
        adicionarComponente(lbSabores, GridBagConstraints.NONE,
                4, 0, 1, 1);

        
        txtSabores = new JTextField(16);
        txtSabores.setEditable(true);
        adicionarComponente(txtSabores, GridBagConstraints.BOTH,
                4, 4, 1, 1);
         
        
            
       
     
        
 
        
        
        lbNumero = new JLabel("Digite o número do cartão");
        adicionarComponente(lbNumero, GridBagConstraints.NONE,
                16, 0, 1, 1);
                
       txtNumero = new JTextField(16);
       txtNumero.setEditable(true); 
       adicionarComponente(txtNumero, GridBagConstraints.BOTH,
                16, 4, 1, 1);
         
        lbEnd = new JLabel("Digite o número da mesa");
        adicionarComponente(lbEnd, GridBagConstraints.NONE,
                20, 0, 1, 1);
                
       txtEnd = new JTextField(16);
       txtEnd.setEditable(true);
        adicionarComponente(txtEnd, GridBagConstraints.BOTH,
                20, 4, 1, 1);
        
        lbPrecoTotal = new JLabel("Preço Total:");
        adicionarComponente(lbPrecoTotal, GridBagConstraints.NONE,
                22, 0, 1, 1);
                
       txtPrecoTotal = new JTextField(16);
       txtPrecoTotal.setEditable(false);
        adicionarComponente(txtPrecoTotal, GridBagConstraints.BOTH,
                22, 4, 1, 1);
     
        
       
         
         btnFinalizar = new JButton("Salvar edição");
         adicionarComponente(btnFinalizar,GridBagConstraints.BOTH , 24, 0, 1, 1); 
          
          
         JButton btnVoltar = new JButton("Voltar");
         adicionarComponente(btnVoltar,GridBagConstraints.BOTH , 24, 4, 1, 1);  
         
         btnVoltar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               dispose();
                
            }
        });
        
        btnFinalizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                salvarEdicao(bancadaSel);
                }catch(Exception ex) {
                    Logger.getLogger(EditarBancada.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

     private void adicionarComponente(Component comp,
            int fill, int linha, int coluna,
            int largura, int altura) {
        gbc3.anchor = GridBagConstraints.LINE_START;
        gbc3.fill = fill;
        gbc3.gridx = coluna;
        gbc3.gridy = linha;
        gbc3.gridwidth = largura;
        gbc3.gridheight = altura;
        //gbc3.insets = new Insets(4, 3, 3, 3);
        gbl3.setConstraints(comp, gbc3);
        add(comp);
    }
/*
     Exibição dos dados do pedido na tela
     */
 private void exibirPedido(Bancada bancada){
    
     txtCodigo.setText(Integer.toString(bancada.getNpedido())); 
     txtQtde.setText(bancada.getPizzaqtde());
     txtNumero.setText(bancada.getCartao());
     txtEnd.setText(Integer.toString(bancada.getMesa()));
     txtSabores.setText(bancada.getSabor());
     txtPrecoTotal.setText(String.valueOf(bancada.getPrecototal()));
     
 
 }
 private void salvarEdicao(Bancada bancada)throws Exception{
 try{   
 bancada.setMesa(txtEnd.getText());
 bancada.setNPedido(Integer.parseInt(txtCodigo.getText()));
 bancada.setQtde(txtQtde.getText());
 bancada.setSabor(txtSabores.getText());
 bancada.setCartao(txtNumero.getText());
 w= 20*Integer.parseInt(txtQtde.getText());
 bancada.setPreco(w);
 JOptionPane.showMessageDialog(null, "Atualização realizada com sucesso!", "Delivery", JOptionPane.INFORMATION_MESSAGE);
            dispose();
 }catch(Exception e){
     JOptionPane.showMessageDialog(null, "Erro ao!\nO código ou quantidade deve conter apenas números!", "Erro!", JOptionPane.ERROR_MESSAGE);
 }
 
 }
 
}