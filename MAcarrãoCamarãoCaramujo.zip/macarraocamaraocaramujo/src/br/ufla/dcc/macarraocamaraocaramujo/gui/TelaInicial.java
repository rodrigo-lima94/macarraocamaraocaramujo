package br.ufla.dcc.macarraocamaraocaramujo.gui;


import br.ufla.dcc.macarraocamaraocaramujo.modelo.Cardapio;
import static br.ufla.dcc.macarraocamaraocaramujo.gui.VerDelivery.n;

import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * /**
 Esta Classe é responsável pela interface Grafica da tela inicial 
 * do software MacarrãoCamarãCaramujo, implementado como trabalho final da disciplina de POO 2016-02.
 * Versao 1.0
 * Autores Grupo MacarrãoCamarãoCaramujo
 */
public class TelaInicial extends JFrame {
    private GridBagLayout gbl;
    private GridBagConstraints gbc;
    private TelaPrincipal tp;
    private TelaAutenticacao ta;
   /**
    * Set parametros da tela
    */
    public TelaInicial() {
        
       
        gbl = new GridBagLayout();
        gbc = new GridBagConstraints();
        
        setSize(650, 420);
        setLayout(gbl);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        construirTela();
    }
        
        /**
         * Criação dos Componentes da tela como Caixas de Textos, textos e Botoes,
         * e atribuição de funções para alguns componentes
         */
       public void construirTela() {
       
        
        tp = new TelaPrincipal();   
        ta = new  TelaAutenticacao(tp);
                
        JLabel lbSaudacao = new JLabel("Bem vindo(a)!!");
        adicionarComponente(lbSaudacao, GridBagConstraints.BOTH, 0, 0, 1, 1);
        
        JLabel lbNome = new JLabel();
        lbNome.setText(String.valueOf(ta.getLogin()));
        adicionarComponente(lbNome, GridBagConstraints.BOTH, 0, 1, 1, 1);
        
        JLabel lbPergunta = new JLabel("Acesse alguma das seguintes opções:");
        adicionarComponente(lbPergunta, GridBagConstraints.BOTH, 2, 0, 1, 1);
        
        
        JButton btnCardapio = new JButton("Cardapio", new ImageIcon(getClass().getResource("/img/visualizar.png")));
        adicionarComponente(btnCardapio,GridBagConstraints.BOTH ,4, 0, 1, 1);
         
                 
      
        

        JComboBox<String> Pedido;
        Pedido = new JComboBox<String>();
        Pedido.addItem("Pedido Delivery");
        Pedido.addItem("Pedido realizado na bancada");
     
        adicionarComponente(Pedido, GridBagConstraints.NONE,
                6, 0, 1, 1);
         

        JButton btnPedido = new JButton("Cadastrar Pedido", new ImageIcon(getClass().getResource("/img/adicionar.png")));
        adicionarComponente(btnPedido, GridBagConstraints.BOTH, 6, 1, 1, 1);
        
       
        
         JButton btnSair = new JButton("Sair", new ImageIcon(getClass().getResource("/img/sair.png")) );
         adicionarComponente(btnSair, GridBagConstraints.BOTH, 13, 0, 1, 1);
         
        JButton btnEditarDelivery = new JButton("Editar Pedido Delivery");
        adicionarComponente(btnEditarDelivery, GridBagConstraints.BOTH, 12, 0, 1, 1);
        
        JButton btnEditarBancada = new JButton("Editar Pedido Bancada");
        adicionarComponente(btnEditarBancada, GridBagConstraints.BOTH, 12, 1, 1, 1);
        
         JButton btnApagarDelivery = new JButton("Apagar Pedido Delivery");
        adicionarComponente(btnApagarDelivery, GridBagConstraints.BOTH, 11, 0, 1, 1);
        
        JButton btnApagarBancada = new JButton("Apagar Pedido Bancada");
        adicionarComponente(btnApagarBancada, GridBagConstraints.BOTH, 11, 1, 1, 1);
        
         

        JButton btnRegistro = new JButton("Ver lista de pedidos", new ImageIcon(getClass().getResource("/img/visualizar.png")));
         adicionarComponente(btnRegistro, GridBagConstraints.BOTH, 9, 0, 1, 1);
         
         JButton btnBuscarPedido = new JButton("Buscar Pedido");
        adicionarComponente(btnBuscarPedido, GridBagConstraints.BOTH, 9, 1, 1, 1);
         
        btnBuscarPedido.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new BuscarPedidoBancada().setVisible(true);
            }
        });
        
        
         btnRegistro.addActionListener(new ActionListener() {
            @Override
                      
            public void actionPerformed(ActionEvent e) {
               
                new TelaRegistro().setVisible(true);
                
            }
        });
         
         btnEditarDelivery.addActionListener(new ActionListener() {
            @Override
                      
            public void actionPerformed(ActionEvent e) {
              new EditarDelivery().setVisible(true);   
               
                
            }
        });
         
         
         btnEditarBancada.addActionListener(new ActionListener() {
            @Override
                      
            public void actionPerformed(ActionEvent e) {
              new EditarBancada().setVisible(true);   
               
                
            }
        });
         
         
         btnApagarDelivery.addActionListener(new ActionListener() {
            @Override
                      
            public void actionPerformed(ActionEvent e) {
              new TelaRemoverDelivery().setVisible(true);   
               
                
            }
        });
         
         btnApagarBancada.addActionListener(new ActionListener() {
            @Override
                      
            public void actionPerformed(ActionEvent e) {
              new TelaRemoverBancada().setVisible(true);   
               
                
            }
        }); 
             
        
        btnCardapio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Cardapio().setVisible(true);
            }
        });
         
         btnSair.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               dispose();                             
            }
        });
               
       btnPedido.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               n = Pedido.getSelectedItem().toString();
                if (n=="Pedido Delivery"){
                new VerDelivery().setVisible(true);
                }
                else{
                     new VerBancada().setVisible(true);
                }
            }
        });
       
       
    } 
       
     /**
     * Adiciona um componente à tela.
     */
    private void adicionarComponente(Component comp,
            int fill, int linha, int coluna,
            int largura, int altura) {
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.fill = fill;
        gbc.gridx = coluna;
        gbc.gridy = linha;
        gbc.gridwidth = largura;
        gbc.gridheight = altura;
        gbc.insets = new Insets(10, 3, 3, 3);
        gbl.setConstraints(comp, gbc);
        add(comp);
    }

      
}
